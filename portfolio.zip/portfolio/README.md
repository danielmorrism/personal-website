# Aria Voss — Portfolio

Personal designer portfolio website. Simple, elegant, minimal.

## Structure

```
/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── main.js
└── README.md
```

## Features

- Masonry-style work grid with hover reveal
- Custom lerp cursor (desktop)
- Scroll-triggered entrance animations
- Fully responsive (mobile, tablet, desktop)
- Respects `prefers-reduced-motion`
- Zero dependencies — pure HTML, CSS, JS

## Deploy

Works as a static site. Drop into any host:

- **GitHub Pages** — push to `main`, enable Pages in repo Settings
- **Netlify** — drag & drop the folder
- **Vercel** — `vercel` in the directory

## Customise

1. Replace placeholder `grid__image` divs with real `<img>` tags or `background-image` URLs
2. Update name, bio, email, and social links in `index.html`
3. Adjust the color palette in `css/style.css` (search `#FAFAF8`, `#0A0A0A`)
